"""Adult Anime Library - a Kodi video addon for your own personal video library.

Point it at one of these in the addon settings:
  * a JSON feed URL (http/https)
  * a JSON file (local path or network share)
  * a folder of video files (subfolders become genres)
"""
import json
import os
import random
import sys
import time
from urllib.parse import parse_qsl, urlencode
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_NAME = ADDON.getAddonInfo("name")
ADDON_ID = ADDON.getAddonInfo("id")
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
HOME = xbmcgui.Window(10000)

VIDEO_EXTS = (".mp4", ".mkv", ".avi", ".mov", ".wmv", ".m4v", ".webm",
              ".ts", ".flv", ".mpg", ".mpeg")
IMAGE_EXTS = (".jpg", ".jpeg", ".png", ".webp")
HISTORY_LIMIT = 50
UNLOCK_SECONDS = 30 * 60
MAX_SCAN_DEPTH = 3
UNLOCK_PROPERTY = "adultlibrary.unlocked_until"


# --------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------

def log(message, level=xbmc.LOGINFO):
    xbmc.log("[{}] {}".format(ADDON_ID, message), level)


def notify(message, icon=xbmcgui.NOTIFICATION_INFO):
    xbmcgui.Dialog().notification(ADDON_NAME, message, icon, 3000)


def build_url(**params):
    return "{}?{}".format(BASE_URL, urlencode(params))


def setting_int(key, default):
    try:
        return ADDON.getSettingInt(key)
    except Exception:
        return default


def to_int(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


def read_json(name, default):
    try:
        with open(os.path.join(PROFILE, name), "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return default


def write_json(name, data):
    try:
        xbmcvfs.mkdirs(PROFILE)
        with open(os.path.join(PROFILE, name), "w", encoding="utf-8") as fh:
            json.dump(data, fh)
    except OSError as exc:
        log("could not write {}: {}".format(name, exc), xbmc.LOGERROR)


def delete_file(name):
    try:
        os.remove(os.path.join(PROFILE, name))
    except OSError:
        pass


def end_action():
    """Finish a non-listing action started from a list entry."""
    if HANDLE >= 0:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


# --------------------------------------------------------------------------
# PIN lock (stays unlocked for 30 minutes after a correct PIN)
# --------------------------------------------------------------------------

def unlocked():
    pin = ADDON.getSetting("pin").strip()
    if not pin:
        return True
    try:
        until = float(HOME.getProperty(UNLOCK_PROPERTY) or 0)
    except ValueError:
        until = 0
    if time.time() < until:
        return True
    entered = xbmcgui.Dialog().numeric(0, "Enter PIN")
    if entered == pin:
        HOME.setProperty(UNLOCK_PROPERTY, str(time.time() + UNLOCK_SECONDS))
        return True
    if entered:
        notify("Wrong PIN", xbmcgui.NOTIFICATION_ERROR)
    return False


# --------------------------------------------------------------------------
# Loading the library
# --------------------------------------------------------------------------

def split_genres(value):
    parts = value if isinstance(value, list) else str(value or "").split(",")
    return [str(p).strip() for p in parts if str(p).strip()]


def normalize(raw):
    if not isinstance(raw, dict):
        return None
    url = str(raw.get("url") or "").strip()
    if not url:
        return None
    title = (str(raw.get("title") or "").strip()
             or os.path.basename(url.split("?")[0]) or "Untitled")
    return {
        "title": title,
        "url": url,
        "thumb": str(raw.get("thumb") or "").strip(),
        "plot": str(raw.get("plot") or "").strip(),
        "genres": split_genres(raw.get("genre", raw.get("genres", ""))),
        "year": raw.get("year"),
        "duration": raw.get("duration"),
        "studio": str(raw.get("studio") or "").strip(),
        "subtitle": str(raw.get("subtitle") or "").strip(),
    }


def is_json_source(source):
    low = source.lower()
    return low.startswith(("http://", "https://")) or low.endswith(".json")


def read_text(source):
    if source.lower().startswith(("http://", "https://")):
        req = Request(source, headers={"User-Agent": "Kodi"})
        with urlopen(req, timeout=15) as resp:
            data = resp.read()
    else:
        handle = xbmcvfs.File(source)
        try:
            data = handle.readBytes()
        finally:
            handle.close()
    return bytes(data).decode("utf-8-sig")


def scan_folder(path, genre="", depth=0):
    """Turn a folder of video files into feed entries. Subfolders = genres."""
    items = []
    base = path.rstrip("/\\") + "/"
    try:
        dirs, files = xbmcvfs.listdir(base)
    except Exception as exc:
        log("cannot list {}: {}".format(base, exc), xbmc.LOGERROR)
        return items
    lowered = {name.lower(): name for name in files}
    for name in sorted(files, key=str.lower):
        stem, ext = os.path.splitext(name)
        if ext.lower() not in VIDEO_EXTS:
            continue
        thumb = ""
        for image_ext in IMAGE_EXTS:
            match = lowered.get((stem + image_ext).lower())
            if match:
                thumb = base + match
                break
        items.append({
            "title": stem.replace("_", " "),
            "url": base + name,
            "thumb": thumb,
            "genre": genre,
        })
    if depth < MAX_SCAN_DEPTH:
        for sub in sorted(dirs, key=str.lower):
            items.extend(scan_folder(base + sub, genre or sub, depth + 1))
    return items


def load_feed(force=False):
    """Return the list of videos, [] if empty, or None if it failed to load."""
    source = ADDON.getSetting("source").strip()
    if not source:
        if xbmcgui.Dialog().yesno(
                ADDON_NAME, "No video source is set yet. Open settings now?"):
            ADDON.openSettings()
        return None

    ttl = setting_int("cache_minutes", 30) * 60
    cache = read_json("cache.json", {})
    if (not force and ttl > 0 and cache.get("source") == source
            and time.time() - cache.get("time", 0) < ttl):
        return cache.get("items", [])

    try:
        if is_json_source(source):
            raw = json.loads(read_text(source))
            if isinstance(raw, dict):
                raw = raw.get("videos", [])
        else:
            raw = scan_folder(source)
        items = [i for i in (normalize(r) for r in raw) if i]
    except Exception as exc:
        log("feed error: {}".format(exc), xbmc.LOGERROR)
        notify("Could not load your library (see Kodi log)",
               xbmcgui.NOTIFICATION_ERROR)
        if cache.get("source") == source:
            return cache.get("items", [])
        return None

    write_json("cache.json", {"source": source, "time": time.time(), "items": items})
    return items


def get_items(force=False):
    return load_feed(force) or []


def sort_items(items):
    mode = setting_int("sort_order", 0)
    if mode == 0:
        return sorted(items, key=lambda i: i["title"].lower())
    if mode == 1:
        return sorted(items, key=lambda i: i["title"].lower(), reverse=True)
    if mode == 3:
        return list(reversed(items))
    return list(items)


# --------------------------------------------------------------------------
# Favorites and history
# --------------------------------------------------------------------------

def find_item(url):
    for source in (get_items(), read_json("favorites.json", []),
                   read_json("history.json", [])):
        for item in source:
            if item.get("url") == url:
                return item
    return None


def add_favorite(url):
    item = find_item(url)
    if not item:
        notify("Could not find that video", xbmcgui.NOTIFICATION_ERROR)
        return
    favs = [f for f in read_json("favorites.json", []) if f.get("url") != url]
    favs.append(item)
    write_json("favorites.json", favs)
    notify("Added to favorites")
    xbmc.executebuiltin("Container.Refresh")


def remove_favorite(url):
    favs = [f for f in read_json("favorites.json", []) if f.get("url") != url]
    write_json("favorites.json", favs)
    notify("Removed from favorites")
    xbmc.executebuiltin("Container.Refresh")


def add_history(item):
    history = [h for h in read_json("history.json", []) if h.get("url") != item["url"]]
    history.insert(0, item)
    write_json("history.json", history[:HISTORY_LIMIT])


# --------------------------------------------------------------------------
# Building lists
# --------------------------------------------------------------------------

def apply_info(li, item):
    year = to_int(item.get("year"))
    duration = to_int(item.get("duration"))
    try:
        tag = li.getVideoInfoTag()
    except AttributeError:  # Kodi 19 (Matrix)
        info = {"mediatype": "video", "title": item["title"], "plot": item["plot"]}
        if item["genres"]:
            info["genre"] = " / ".join(item["genres"])
        if year:
            info["year"] = year
        if duration:
            info["duration"] = duration
        if item["studio"]:
            info["studio"] = item["studio"]
        li.setInfo("video", info)
        return
    tag.setMediaType("video")
    tag.setTitle(item["title"])
    tag.setPlot(item["plot"])
    if item["genres"]:
        tag.setGenres(item["genres"])
    if year:
        tag.setYear(year)
    if duration:
        tag.setDuration(duration)
    if item["studio"]:
        tag.setStudios([item["studio"]])


def make_listitem(item, fav_urls):
    li = xbmcgui.ListItem(label=item["title"])
    if item["thumb"]:
        li.setArt({"thumb": item["thumb"], "icon": item["thumb"],
                   "poster": item["thumb"]})
    apply_info(li, item)
    li.setProperty("IsPlayable", "true")
    if item["url"] in fav_urls:
        label, action = "Remove from favorites", "unfav"
    else:
        label, action = "Add to favorites", "fav"
    li.addContextMenuItems([
        (label, "RunPlugin({})".format(build_url(action=action, video=item["url"])))
    ])
    return li


def add_dir(label, **params):
    xbmcplugin.addDirectoryItem(
        HANDLE, build_url(**params), xbmcgui.ListItem(label=label), True)


def add_action(label, **params):
    li = xbmcgui.ListItem(label=label)
    li.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(HANDLE, build_url(**params), li, False)


def list_videos(items, params, page=0, sort=True, empty_text="No videos found."):
    if sort:
        items = sort_items(items)
    per_page = setting_int("items_per_page", 50)
    total = len(items)
    if per_page > 0:
        start = page * per_page
        chunk = items[start:start + per_page]
        pages = (total + per_page - 1) // per_page
    else:
        chunk, pages = items, 1

    fav_urls = {f.get("url") for f in read_json("favorites.json", [])}
    for item in chunk:
        xbmcplugin.addDirectoryItem(
            HANDLE, build_url(action="play", video=item["url"]),
            make_listitem(item, fav_urls), False)
    if per_page > 0 and page + 1 < pages:
        add_dir("Next page ({}/{}) >>".format(page + 2, pages),
                **dict(params, page=page + 1))
    if not chunk:
        notify(empty_text)
    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.endOfDirectory(HANDLE)


# --------------------------------------------------------------------------
# Screens
# --------------------------------------------------------------------------

def root():
    add_dir("All videos", action="all")
    add_dir("Genres", action="genres")
    add_dir("Search", action="search")
    add_dir("Favorites", action="favorites")
    add_dir("Recently watched", action="history")
    add_action("Random video", action="random")
    add_action("Refresh library", action="refresh")
    add_action("Settings", action="settings")
    xbmcplugin.endOfDirectory(HANDLE)


def show_genres():
    counts, names = {}, {}
    for item in get_items():
        for genre in item["genres"]:
            key = genre.lower()
            names.setdefault(key, genre)
            counts[key] = counts.get(key, 0) + 1
    for key in sorted(counts):
        add_dir("{} ({})".format(names[key], counts[key]),
                action="genre", genre=names[key])
    if not counts:
        notify("No genres found. Add a \"genre\" to your videos or use subfolders.")
    xbmcplugin.endOfDirectory(HANDLE)


def show_genre(genre, page):
    wanted = genre.lower()
    items = [i for i in get_items() if wanted in [g.lower() for g in i["genres"]]]
    list_videos(items, {"action": "genre", "genre": genre}, page)


def show_search(query, page):
    if query is None:
        query = xbmcgui.Dialog().input("Search")
        if not query:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
            return
    needle = query.lower()

    def matches(item):
        haystack = " ".join([item["title"], item["plot"], item["studio"]]
                            + item["genres"]).lower()
        return needle in haystack

    list_videos([i for i in get_items() if matches(i)],
                {"action": "search", "q": query}, page,
                empty_text="Nothing matched \"{}\".".format(query))


def play(url):
    item = find_item(url)
    li = xbmcgui.ListItem(label=item["title"] if item else "", path=url)
    if item and item["thumb"]:
        li.setArt({"thumb": item["thumb"]})
    if item and item["subtitle"]:
        li.setSubtitles([item["subtitle"]])
    xbmcplugin.setResolvedUrl(HANDLE, True, li)
    if item:
        add_history(item)


def play_random():
    items = get_items()
    if not items:
        notify("No videos found.")
        end_action()
        return
    play(random.choice(items)["url"])


# --------------------------------------------------------------------------
# Router
# --------------------------------------------------------------------------

def router(paramstring):
    params = dict(parse_qsl(paramstring))
    action = params.get("action")
    page = to_int(params.get("page"))
    video = params.get("video", "")

    # Actions that show no content, so no PIN is needed.
    if action == "clear_cache":
        delete_file("cache.json")
        notify("Cache cleared")
        return
    if action == "clear_history":
        delete_file("history.json")
        notify("Recently watched cleared")
        return
    if action == "test":
        items = load_feed(force=True)
        if items is None:
            return
        notify("Found {} video(s)".format(len(items)) if items
               else "Source loaded, but no videos were found",
               xbmcgui.NOTIFICATION_INFO if items else xbmcgui.NOTIFICATION_WARNING)
        return
    if action == "fav":
        add_favorite(video)
        return
    if action == "unfav":
        remove_favorite(video)
        return

    if not unlocked():
        if action in ("play", "random", "refresh", "settings"):
            end_action()
        else:
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    if action is None:
        root()
    elif action == "all":
        list_videos(get_items(), {"action": "all"}, page)
    elif action == "genres":
        show_genres()
    elif action == "genre":
        show_genre(params.get("genre", ""), page)
    elif action == "search":
        show_search(params.get("q"), page)
    elif action == "favorites":
        list_videos(read_json("favorites.json", []), {"action": "favorites"}, page,
                    empty_text="No favorites yet. Use the context menu on a video.")
    elif action == "history":
        list_videos(read_json("history.json", []), {"action": "history"}, page,
                    sort=False, empty_text="Nothing watched yet.")
    elif action == "play":
        play(video)
    elif action == "random":
        play_random()
    elif action == "refresh":
        items = load_feed(force=True)
        if items is not None:
            notify("Library refreshed: {} video(s)".format(len(items)))
        end_action()
    elif action == "settings":
        ADDON.openSettings()
        end_action()


if __name__ == "__main__":
    router(sys.argv[2][1:])
